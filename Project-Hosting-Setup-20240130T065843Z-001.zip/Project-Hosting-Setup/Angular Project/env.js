(function(window) {
  window["env"] = window["env"] || {};

  // Environment variables
  window["env"]["apiUrl"] = "https://api.myapp.com";
  window["env"]["debug"] = true;
})(this);